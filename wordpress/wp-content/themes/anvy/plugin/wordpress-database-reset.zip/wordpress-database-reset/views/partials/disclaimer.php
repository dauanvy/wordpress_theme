<p id="disclaimer" style="display: none">
  <em><?php printf( __( 'You selected the users table. Only the <strong><u>%s</u></strong> user will be restored', 'wordpress-database-reset' ), $this->user->user_login ) ?>.</em>
</p>
